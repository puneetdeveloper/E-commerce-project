export class Product {
    id!:number;
    title!: string;
    Price!: number;
    color?: string;
    discount!: number;
    photo!: string;
    detail?:string;
}